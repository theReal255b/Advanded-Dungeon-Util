import "./Terminalstuff/main.js";
import "./Dungeonstuff/mobscan.js";
import "./Dungeonstuff/pdroutes.js";
import "./configs/commands.js";
