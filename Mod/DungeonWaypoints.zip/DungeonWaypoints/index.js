import "./Terminalstuff/main.js";
import "./Dungeonstuff/mobscan.js";
import "./configs/commands.js";
